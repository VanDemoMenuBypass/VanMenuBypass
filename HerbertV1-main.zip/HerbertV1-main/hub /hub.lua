local Library = loadstring(game:HttpGet("https://raw.githubusercontent.com/xHeptc/Kavo-UI-Library/main/source.lua"))()
local Window = Library.CreateLib("Hubert Hub V1", "DarkTheme")

--// FD SCRIPTS TAB \\--

local Tab = Window:NewTab("FD Scripts")
local KnifeSection = Tab:NewSection("Grab Knife")
local RoXploitSection = Tab:NewSection("Ro-Xploit")
local CoolkidSection = Tab:NewSection("Coolkid")
local Section = Tab:NewSection("Basic")


KnifeSection:NewButton("Grab Knife V1", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/SSAzNj10", true))()
end)

KnifeSection:NewButton("Grab Knife V2", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/Bw7aWTBL", true))()
end)

KnifeSection:NewButton("Grab Knife V3", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/frHvA27v", true))()
end)

KnifeSection:NewButton("Grab Knife V4", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/ANs9UDrn", true))()
end)

CoolkidSection:NewButton("Coolkid V4", "ButtonInfo", function()
    loadstring(game:GetObjects("rbxassetid://157645868")[1].Source)()
end)

CoolkidSection:NewButton("Coolkid V3", "ButtonInfo", function()
    loadstring(game:GetObjects("rbxassetid://142756431")[1].Source)()
end)

RoXploitSection:NewButton("Ro-Xploit 4.0", "ButtonInfo", function()
    loadstring(game:GetObjects("rbxassetid://175137115")[1].Source)()
end)

RoXploitSection:NewButton("Ro-Xploit 5.0", "ButtonInfo", function()
    loadstring(game:GetObjects("rbxassetid://288646117")[1].Source)()
end)

RoXploitSection:NewButton("Ro-Xploit 6.0", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/qqgpugGF", true))()
end)


Section:NewButton("YourMom GUI", "ButtonInfo", function()
    loadstring(game:GetObjects('rbxassetid://289110135')[1].Source)()
end)


Section:NewButton("Kappa GUI", "ButtonInfo", function()
    loadstring(game:GetObjects("rbxassetid://277963953")[1].Source)()
end)


Section:NewButton("Phantom X", "ButtonInfo", function()
    loadstring(game:GetObjects("rbxassetid://296648575")[1].Source)()
end)


Section:NewButton("PME's Commands", "ButtonInfo", function()
    loadstring(game:GetObjects("rbxassetid://303367841")[1].Source)()
end)


Section:NewButton("Scythe", "ButtonInfo", function()
    loadstring(game:GetObjects("rbxassetid://112829174")[1].Source)()
end)

Section:NewButton("666", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/d56eg7r9"))()
end)

Section:NewButton("Lua Hammer", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/RKY5fTXh", true))()
end)

Section:NewButton("Brock", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/LvRVzzTL", true))()
end)

Section:NewButton("Bird Wings", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/zCypYHjJ", true))()
end)

Section:NewButton("Doge", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/31xeU3pX", true))()
end)

Section:NewButton("Rose Hub", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/9q2nraUs", true))()
end)

Section:NewButton("Dev-Uzi", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/X2n20xqM", true))()
end)

Section:NewButton("Safazi Rocky2u", "ButtonInfo", function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/LuaGunsX/LuasLegacyScripts/main/%5BAdmin%5D%20Rocky2u%20Edit", true))()
end)

Section:NewButton("Trump Titan", "ButtonInfo", function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/LuaGunsX/LuasLegacyScripts/main/%5BTitans%5D%20Trump", true))()
end)

Section:NewButton("UVG", "ButtonInfo", function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/LuaGunsX/LuasLegacyScripts/main/%5BGUI%5D%20Ultimate%20Van%20GUI", true))()
end)

Section:NewButton("T0PK3K 0.8", "ButtonInfo", function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/LuaGunsX/LuasLegacyScripts/main/%5BGUI%5D%20T0PK3K%200.8", true))()
end)

Section:NewButton("T0PK3K 2.0", "ButtonInfo", function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/LuaGunsX/LuasLegacyScripts/main/%5BGUI%5D%20T0PK3K%20V2", true))()
end)

Section:NewButton("T0PK3K 3.0", "ButtonInfo", function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/LuaGunsX/LuasLegacyScripts/main/%5BGUI%5D%20T0PK3K%20V3", true))()
end)

Section:NewButton("T0PK3K 4.0", "ButtonInfo", function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/LuaGunsX/LuasLegacyScripts/main/%5BGUI%5D%20T0PK3K%20V4", true))()
end)

Section:NewButton("Nebula Hub", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/fHGzkgyU", true))()
end)

Section:NewButton("Nae Nae", "ButtonInfo", function()
    loadstring(game:HttpGet("https://files.catbox.moe/dwlll4.txt", true))()
end)

Section:NewButton("iOrb 2.0", "ButtonInfo", function()
    loadstring(game:HttpGet("https://files.catbox.moe/uhtmgb.lua", true))()
end)

--// GAME SCRIPTS TAB \\--

local Tab = Window:NewTab("Game Scripts")
local SS = Tab:NewSection("All Games")

SS:NewButton("Virgo V3", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/EwYDRD4Y", true))()
end)

SS:NewButton("Apoc Tools V4", "ButtonInfo", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/0de4tAtR", true))()
end)
