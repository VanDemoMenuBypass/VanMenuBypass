# roblox-hwid-ban-remover
Remove a HWID ban that prevents you from playing ROBLOX. Please note that this will not help restore functionality to publishing places in ROBLOX Studio.

How to use the tool:

1. Do either of these:
- Download the precompiled release: https://github.com/6K6666/roblox-hwid-ban-remover/releases/tag/roblox-hwid-ban-remover
- Compile the exe yourself

2. The app will open an icon in your system tray. Click the icon to install the HWID ban remover into the ROBLOX directory. It will open a pop-up window when it has successfully done so.

The app was made with convienience in mind due to the fact that ROBLOX will overwrite files in it's directory when it updates therefore removing the HWID ban bypasser.

How to use manually:

1. Find your Roblox Player desktop shortcut and right click it. Click "Open file location"

https://i.imgur.com/HcOJ32G.png

2. Paste the d3d9.dll file into that folder that you are now in with the RobloxPlayerBeta/RobloxPlayerLauncher files

Final product should look like/similar to this:

https://i.imgur.com/g8c0wEV.png
